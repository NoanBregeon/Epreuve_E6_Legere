<?php echo e($slot); ?>

<?php /**PATH C:\code\Epreuve_E6_Legere\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>