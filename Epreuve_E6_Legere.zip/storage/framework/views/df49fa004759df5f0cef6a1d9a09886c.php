<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\code\Epreuve_E6_Legere\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>