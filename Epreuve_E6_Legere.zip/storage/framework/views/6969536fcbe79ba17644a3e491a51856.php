<!-- filepath: c:\code\Epreuve_E6_Legere\resources\views\welcome.blade.php -->
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drive - Courses en ligne</title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-brand">Drive</div>
            <div class="nav-menu">
                <a href="/" class="nav-link">Accueil</a>
                <a href="/produits" class="nav-link">Produits</a>
                <a href="/panier" class="nav-link">Mon panier</a>
                <a href="/compte" class="nav-link">Mon compte</a>
                <?php if(auth()->guard()->check()): ?>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="nav-link btn-link">Déconnexion</button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="nav-link">Connexion</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-content">
            <h1>Faites vos courses en ligne<br>simplement et rapidement</h1>
            <p>Commandez en quelques clics et récupérez votre panier au Drive.</p>
            <a href="/produits" class="btn-primary">Découvrir les produits</a>
        </div>
    </section>

    <!-- Features -->
    <section class="features-section">
        <div class="container">
            <div class="features-list">
                <div class="feature-row">
                    <div class="feature-row-icon">
                        <img src="<?php echo e(asset('icons/drive.svg')); ?>"
                            alt="Retrait rapide au Drive"
                            width="36" height="36"
                            loading="lazy">
                    </div>
                    <div class="feature-row-text">
                        <h3>Retrait rapide au Drive</h3>
                        <p>Récupérez vos courses sans sortir de votre voiture</p>
                    </div>
                </div>
                <div class="feature-row">
                    <div class="feature-row-icon">
                        <img src="<?php echo e(asset('icons/secure.svg')); ?>"
                            alt="Paiement sécurisé"
                            width="36" height="36"
                            loading="lazy">
                    </div>
                    <div class="feature-row-text">
                        <h3>Paiement sécurisé</h3>
                        <p>Vos données bancaires sont protégées</p>
                    </div>
                </div>
                <div class="feature-row">
                    <div class="feature-row-icon">
                        <img src="<?php echo e(asset('icons/fresh.svg')); ?>"
                            alt="Produits frais garantis"
                            width="36" height="36"
                            loading="lazy">
                    </div>
                    <div class="feature-row-text">
                        <h3>Produits frais garantis</h3>
                        <p>Fraîcheur et qualité assurées</p>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <!-- Products Section -->
    <section class="products">
        <div class="container">
            <h2>Produits populaires</h2>
            <div class="products-grid">
                <?php for($i = 1; $i <= 6; $i++): ?>
                <div class="product-card">
                    <div class="product-image">
                        <div class="product-placeholder">
                            <span>Produit <?php echo e($i); ?></span>
                        </div>
                    </div>
                    <div class="product-info">
                        <h3>Produit exemple <?php echo e($i); ?></h3>
                        <p class="product-description">Description du produit</p>
                        <p class="price"><?php echo e(number_format(rand(200, 999) / 100, 2)); ?> € TTC</p>
                        <button class="btn-add-cart">Ajouter au panier</button>
                    </div>
                </div>
                <?php endfor; ?>
            </div>
            <div class="text-center">
                <a href="/produits" class="btn-secondary">Voir tous les produits</a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>© 2025 Drive – Projet BTS SIO SLAM – Page d'accueil</p>
        </div>
    </footer>
</body>
</html>
<?php /**PATH C:\code\Epreuve_E6_Legere\resources\views/welcome.blade.php ENDPATH**/ ?>