<?php $__env->startSection('title', 'Produits - Drive'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div class="container">
        <h1 class="page-title">Tous les produits</h1>
        <p class="page-subtitle">Consultez les produits disponibles sur le Drive.</p>
    </div>
</div>

<section class="content-section">
    <div class="container">
        <!-- Filtres et Recherche -->
        <div class="filters-bar" style="margin-bottom: 2rem; display: flex; gap: 1rem; justify-content: space-between; flex-wrap: wrap;">
            <form action="<?php echo e(route('produits.index')); ?>" method="GET" style="display: flex; gap: 0.5rem;">
                <input type="text" name="search" placeholder="Rechercher un produit..." value="<?php echo e(request('search')); ?>" class="form-control" style="padding: 0.5rem;">
                <button type="submit" class="btn-primary">Rechercher</button>
            </form>

            <div class="sort-options">
                <a href="<?php echo e(route('produits.index', ['sort' => 'name', 'search' => request('search')])); ?>" class="btn-secondary">Nom</a>
                <a href="<?php echo e(route('produits.index', ['sort' => 'price_asc', 'search' => request('search')])); ?>" class="btn-secondary">Prix croissant</a>
                <a href="<?php echo e(route('produits.index', ['sort' => 'price_desc', 'search' => request('search')])); ?>" class="btn-secondary">Prix décroissant</a>
            </div>
        </div>

        <div class="products-grid">
            <?php $__empty_1 = true; $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="product-card">
                    <div class="product-card-header" style="background-image: url('<?php echo e($produit->image ? Storage::url($produit->image) : 'https://placehold.co/600x400?text=Produit'); ?>'); background-size: cover; background-position: center; height: 200px; position: relative;">
                        <span class="product-category" style="position: absolute; top: 10px; left: 10px;">
                            <?php echo e($produit->categorie ?? 'Produit'); ?>

                        </span>
                    </div>

                    <div class="product-card-body">
                        <h3 class="product-name">
                            <a href="<?php echo e(route('produits.show', $produit->id)); ?>">
                                <?php echo e($produit->libelle); ?>

                            </a>
                        </h3>

                        <p class="product-description">
                            <?php echo e(Str::limit($produit->description, 80) ?? 'Description non renseignée.'); ?>

                        </p>
                        <p class="product-price">
                            <?php echo e(number_format($produit->prix_ttc, 2, ',', ' ')); ?> € TTC
                        </p>
                    </div>

                    <div class="product-card-footer">
                        <form action="<?php echo e(route('panier.add', $produit->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn-primary" <?php echo e(!$produit->isEnStock() ? 'disabled' : ''); ?>>
                                <?php echo e($produit->isEnStock() ? 'Ajouter au panier' : 'Rupture de stock'); ?>

                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Aucun produit disponible pour le moment.</p>
            <?php endif; ?>
        </div>

        <!-- Pagination -->
        <div class="pagination-container" style="margin-top: 2rem; display: flex; justify-content: center;">
            <?php echo e($produits->appends(request()->query())->links()); ?>

        </div>

        <div style="text-align: center; margin-top: 2rem;">
            <a href="<?php echo e(route('accueil')); ?>" class="btn-secondary">
                Retour à l’accueil
            </a>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\code\Epreuve_E6_Legere\resources\views/produits/index.blade.php ENDPATH**/ ?>