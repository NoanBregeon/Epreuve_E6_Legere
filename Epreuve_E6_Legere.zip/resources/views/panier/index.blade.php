@extends('layouts.app')

@section('title', 'Mon panier - Drive')

@section('content')
<div class="page-header">
    <div class="container">
        <h1 class="page-title">Mon panier</h1>
        <p class="page-subtitle">Vérifiez vos articles avant de passer commande</p>
    </div>
</div>

<section class="content-section">
    <div class="container">
        <div class="cart-layout">
            <!-- Cart Items -->
            <div class="cart-items">
                <div class="cart-header">
                    <span class="col-product">Produit</span>
                    <span class="col-quantity">Quantité</span>
                    <span class="col-price">Prix unitaire</span>
                    <span class="col-total">Total</span>
                    <span class="col-actions"></span>
                </div>

                <div class="cart-item">
                    <div class="item-product">
                        <div class="item-image">
                            <div class="product-placeholder">P1</div>
                        </div>
                        <div class="item-info">
                            <h4>Nom du produit</h4>
                            <p>Référence: REF001</p>
                        </div>
                    </div>
                    <div class="item-quantity">
                        <div class="quantity-controls">
                            <button class="qty-btn">-</button>
                            <input type="number" value="1" class="qty-input">
                            <button class="qty-btn">+</button>
                        </div>
                    </div>
                    <div class="item-price">3,99 € TTC</div>
                    <div class="item-total">3,99 € TTC</div>
                    <div class="item-actions">
                        <button class="btn-remove">×</button>
                    </div>
                </div>

                <div class="cart-item">
                    <div class="item-product">
                        <div class="item-image">
                            <div class="product-placeholder">P2</div>
                        </div>
                        <div class="item-info">
                            <h4>Nom du produit</h4>
                            <p>Référence: REF002</p>
                        </div>
                    </div>
                    <div class="item-quantity">
                        <div class="quantity-controls">
                            <button class="qty-btn">-</button>
                            <input type="number" value="1" class="qty-input">
                            <button class="qty-btn">+</button>
                        </div>
                    </div>
                    <div class="item-price">3,99 € TTC</div>
                    <div class="item-total">3,99 € TTC</div>
                    <div class="item-actions">
                        <button class="btn-remove">×</button>
                    </div>
                </div>

                <div class="cart-item">
                    <div class="item-product">
                        <div class="item-image">
                            <div class="product-placeholder">P3</div>
                        </div>
                        <div class="item-info">
                            <h4>Nom du produit</h4>
                            <p>Référence: REF003</p>
                        </div>
                    </div>
                    <div class="item-quantity">
                        <div class="quantity-controls">
                            <button class="qty-btn">-</button>
                            <input type="number" value="1" class="qty-input">
                            <button class="qty-btn">+</button>
                        </div>
                    </div>
                    <div class="item-price">3,99 € TTC</div>
                    <div class="item-total">3,99 € TTC</div>
                    <div class="item-actions">
                        <button class="btn-remove">×</button>
                    </div>
                </div>
            </div>

            <!-- Cart Summary -->
            <div class="cart-summary">
                <h3>Récapitulatif</h3>
                <div class="summary-line">
                    <span>Sous-total</span>
                    <span>11,97 € TTC</span>
                </div>
                <div class="summary-line">
                    <span>Livraison</span>
                    <span>Gratuite</span>
                </div>
                <div class="summary-line total-line">
                    <span><strong>Total du panier: 11,97 € TTC</strong></span>
                </div>

                <form action="/commande" method="POST" class="checkout-form">
                    @csrf
                    <button type="submit" class="btn-checkout">Valider ma commande</button>
                </form>

                <div class="continue-shopping">
                    <a href="/produits" class="btn-continue">Continuer mes achats</a>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
