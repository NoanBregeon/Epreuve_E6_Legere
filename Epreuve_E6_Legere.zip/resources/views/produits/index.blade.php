@extends('layouts.app')

@section('title', 'Produits - Drive')

@section('content')
<div class="page-header">
    <div class="container">
        <h1 class="page-title">Tous les produits</h1>
        <p class="page-subtitle">Consultez les produits disponibles sur le Drive.</p>
    </div>
</div>

<section class="content-section">
    <div class="container">
        <!-- Filtres et Recherche -->
        <div class="filters-bar" style="margin-bottom: 2rem; display: flex; gap: 1rem; justify-content: space-between; flex-wrap: wrap;">
            <form action="{{ route('produits.index') }}" method="GET" style="display: flex; gap: 0.5rem;">
                <input type="text" name="search" placeholder="Rechercher un produit..." value="{{ request('search') }}" class="form-control" style="padding: 0.5rem;">
                <button type="submit" class="btn-primary">Rechercher</button>
            </form>

            <div class="sort-options">
                <a href="{{ route('produits.index', ['sort' => 'name', 'search' => request('search')]) }}" class="btn-secondary">Nom</a>
                <a href="{{ route('produits.index', ['sort' => 'price_asc', 'search' => request('search')]) }}" class="btn-secondary">Prix croissant</a>
                <a href="{{ route('produits.index', ['sort' => 'price_desc', 'search' => request('search')]) }}" class="btn-secondary">Prix décroissant</a>
            </div>
        </div>

        <div class="products-grid">
            @forelse($produits as $produit)
                <div class="product-card">
                    <div class="product-card-header" style="background-image: url('{{ $produit->image ? Storage::url($produit->image) : 'https://placehold.co/600x400?text=Produit' }}'); background-size: cover; background-position: center; height: 200px; position: relative;">
                        <span class="product-category" style="position: absolute; top: 10px; left: 10px;">
                            {{ $produit->categorie ?? 'Produit' }}
                        </span>
                    </div>

                    <div class="product-card-body">
                        <h3 class="product-name">
                            <a href="{{ route('produits.show', $produit->id) }}">
                                {{ $produit->libelle }}
                            </a>
                        </h3>

                        <p class="product-description">
                            {{ Str::limit($produit->description, 80) ?? 'Description non renseignée.' }}
                        </p>
                        <p class="product-price">
                            {{ number_format($produit->prix_ttc, 2, ',', ' ') }} € TTC
                        </p>
                    </div>

                    <div class="product-card-footer">
                        <form action="{{ route('panier.add', $produit->id) }}" method="POST">
                            @csrf
                            <button type="submit" class="btn-primary" {{ !$produit->isEnStock() ? 'disabled' : '' }}>
                                {{ $produit->isEnStock() ? 'Ajouter au panier' : 'Rupture de stock' }}
                            </button>
                        </form>
                    </div>
                </div>
            @empty
                <p>Aucun produit disponible pour le moment.</p>
            @endforelse
        </div>

        <!-- Pagination -->
        <div class="pagination-container" style="margin-top: 2rem; display: flex; justify-content: center;">
            {{ $produits->appends(request()->query())->links() }}
        </div>

        <div style="text-align: center; margin-top: 2rem;">
            <a href="{{ route('accueil') }}" class="btn-secondary">
                Retour à l’accueil
            </a>
        </div>
    </div>
</section>
@endsection
