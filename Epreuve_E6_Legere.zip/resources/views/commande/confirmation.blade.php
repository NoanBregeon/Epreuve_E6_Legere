@extends('layouts.app')

@section('title', 'Commande validée - Drive')

@section('content')
<div class="confirmation-container">
    <div class="confirmation-card">
        <div class="confirmation-icon">
            ✅
        </div>

        <h1 class="confirmation-title">Commande validée !</h1>

        <p class="confirmation-message">
            Votre commande a bien été enregistrée.
        </p>

        <div class="order-summary">
            <h3>Récapitulatif de votre commande</h3>

            <div class="order-details">
                <div class="order-info">
                    <span class="label">Numéro de commande:</span>
                    <span class="value">#{{ $commande->id }}</span>
                </div>
                <div class="order-info">
                    <span class="label">Date:</span>
                    <span class="value">{{ $commande->created_at->format('d/m/Y à H:i') }}</span>
                </div>
                <div class="order-info">
                    <span class="label">Montant total:</span>
                    <span class="value total-amount">{{ number_format($commande->total_ttc, 2, ',', ' ') }} € TTC</span>
                </div>
            </div>
        </div>

        <div class="next-steps">
            <h3>Prochaines étapes</h3>
            <ol class="steps-list">
                <li>Vous recevrez un e-mail de confirmation</li>
                <li>Préparation de votre commande (2-4h)</li>
                <li>Notification SMS pour le retrait</li>
                <li>Retrait au Drive avec votre code</li>
            </ol>
        </div>

        <div class="confirmation-actions">
            <a href="{{ route('produits.index') }}" class="btn-secondary">Continuer mes achats</a>
            <a href="{{ route('commande.index') }}" class="btn-primary">Mes commandes</a>
        </div>
    </div>
</div>
@endsection
