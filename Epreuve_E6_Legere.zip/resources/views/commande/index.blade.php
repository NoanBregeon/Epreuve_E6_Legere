@extends('layouts.app')

@section('title', 'Mes Commandes - Drive')

@section('content')
<div class="page-header">
    <div class="container">
        <h1 class="page-title">Mes Commandes</h1>
        <p class="page-subtitle">Retrouvez l'historique de vos achats</p>
    </div>
</div>

<section class="content-section">
    <div class="container">
        @if($commandes->isEmpty())
            <div class="empty-state">
                <p>Vous n'avez pas encore passé de commande.</p>
                <a href="{{ route('produits.index') }}" class="btn-primary">Commencer mes achats</a>
            </div>
        @else
            <div class="orders-list">
                @foreach($commandes as $commande)
                    <div class="order-card" style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 20px;">
                        <div class="order-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; border-bottom: 1px solid #eee; padding-bottom: 10px;">
                            <div class="order-info">
                                <h3 style="margin: 0; color: #2c3e50;">Commande #{{ $commande->id }}</h3>
                                <span class="order-date" style="color: #7f8c8d; font-size: 0.9em;">{{ $commande->created_at->format('d/m/Y H:i') }}</span>
                            </div>
                            <div class="order-status" style="font-weight: bold; color: #27ae60;">
                                {{ $commande->statut }}
                            </div>
                        </div>
                        <div class="order-body" style="margin-bottom: 15px;">
                            <p style="margin: 5px 0;"><strong>Montant total :</strong> {{ number_format($commande->total_ttc, 2, ',', ' ') }} €</p>
                            <p style="margin: 5px 0;"><strong>Moyen de paiement :</strong> {{ $commande->moyen_paiement }}</p>
                            <p style="margin: 5px 0;"><strong>Articles :</strong> {{ $commande->lignes->count() }}</p>
                        </div>
                        <div class="order-footer" style="text-align: right;">
                            <a href="{{ route('commande.confirmation', $commande->id) }}" class="btn-secondary">Voir le détail</a>
                        </div>
                    </div>
                @endforeach
            </div>

            <div class="pagination">
                {{ $commandes->links() }}
            </div>
        @endif
    </div>
</section>
@endsection
