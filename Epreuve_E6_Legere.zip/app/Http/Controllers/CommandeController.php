<?php

namespace App\Http\Controllers;

use App\Models\LigneTicket;
use App\Models\Ticket;
use App\Services\PanierService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class CommandeController extends Controller
{
    protected PanierService $panierService;

    public function __construct(PanierService $panierService)
    {
        $this->panierService = $panierService;
    }

    /**
     * Afficher les commandes de l'utilisateur
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $commandes = Ticket::where('user_id', Auth::id())
            ->orderBy('created_at', 'desc')
            ->with('lignes.produit')
            ->paginate(10);

        return view('commande.index', compact('commandes'));
    }

    /**
     * Créer une commande depuis le panier
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        if ($this->panierService->estVide()) {
            return redirect()->route('panier.index')
                ->with('error', 'Votre panier est vide.');
        }

        $request->validate([
            'moyen_paiement' => 'required|in:CB,ESPECES,CHEQUE,EN_LIGNE',
        ]);

        DB::beginTransaction();

        try {
            // Créer le ticket
            $ticket = Ticket::create([
                'user_id' => Auth::id(),
                'client_id' => null,
                'total_ht' => $this->panierService->getTotalHT(),
                'total_tva' => $this->panierService->getTotalTVA(),
                'total_ttc' => $this->panierService->getTotalTTC(),
                'moyen_paiement' => $request->moyen_paiement,
                'statut' => 'VALIDE',
            ]);

            // Créer les lignes de ticket
            foreach ($this->panierService->getContenu() as $produitId => $item) {
                LigneTicket::create([
                    'ticket_id' => $ticket->id,
                    'produit_id' => $produitId,
                    'qte' => $item['quantite'],
                    'prix_unitaire_ht' => $item['prix_ht'],
                    'tva' => $item['tva'],
                ]);

                // Décrémenter le stock
                /** @var \App\Models\Produit|null $produit */
                $produit = \App\Models\Produit::find($produitId);
                if ($produit) {
                    $produit->decrement('stock', $item['quantite']);
                }
            }

            DB::commit();

            // Vider le panier
            $this->panierService->vider();

            return redirect()->route('commande.confirmation', $ticket->id)
                ->with('success', 'Commande validée avec succès !');

        } catch (\Exception $e) {
            DB::rollBack();

            return redirect()->route('panier.index')
                ->with('error', 'Une erreur est survenue lors de la validation de votre commande.');
        }
    }

    /**
     * Afficher la confirmation de commande
     *
     * @return \Illuminate\View\View
     */
    public function confirmation(int $id)
    {
        /** @var Ticket $commande */
        $commande = Ticket::with('lignes.produit')->findOrFail($id);

        // Vérifier que l'utilisateur peut voir cette commande
        if (Auth::check() && $commande->user_id && $commande->user_id !== Auth::id()) {
            abort(403, 'Accès interdit');
        }

        return view('commande.confirmation', compact('commande'));
    }
}
